let chart;
let playbackInterval;
let seirData = { S: [], E: [], I: [], R: [] };
let dailyStatus = [];
let x = [], y = [];
let currentMapDay = 0;

function toggleTheme() {
  document.body.classList.toggle("dark");
}

function startPlayback() {
  if (!seirData.S.length) return alert("No data loaded!");
  let current = 0;
  clearInterval(playbackInterval);
  playbackInterval = setInterval(() => {
    if (current >= seirData.S.length) {
      clearInterval(playbackInterval);
      return;
    }
    updateChart(current);
    current++;
  }, 200);
}

function startMapPlayback() {
  if (!dailyStatus.length || !x.length || !y.length) return alert("No animation data!");
  const canvas = document.getElementById("mapCanvas");
  canvas.style.display = "block";
  const ctx = canvas.getContext("2d");
  currentMapDay = 0;

  clearInterval(playbackInterval);
  playbackInterval = setInterval(() => {
    if (currentMapDay >= dailyStatus.length) {
      clearInterval(playbackInterval);
      return;
    }
    drawMap(x, y, dailyStatus[currentMapDay], currentMapDay);
    currentMapDay++;
  }, 300);
}

function drawMap(x, y, statuses, day = 0) {
  const canvas = document.getElementById("mapCanvas");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < x.length; i++) {
    let color = "#ccc";
    switch (statuses[i]) {
      case "S": color = "green"; break;
      case "E": color = "orange"; break;
      case "I": color = "red"; break;
      case "R": color = "blue"; break;
    }
    ctx.beginPath();
    ctx.arc(x[i], y[i], 4, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
  }

  ctx.font = "16px Nunito";
  ctx.fillStyle = "#333";
  ctx.fillText(`Day ${day + 1}`, canvas.width - 80, 25);

  const legend = [
    { label: "Susceptible", color: "green" },
    { label: "Exposed", color: "orange" },
    { label: "Infected", color: "red" },
    { label: "Recovered", color: "blue" }
  ];
  legend.forEach((l, i) => {
    ctx.fillStyle = l.color;
    ctx.beginPath();
    ctx.arc(20, 30 + i * 20, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#333";
    ctx.font = "14px Nunito";
    ctx.fillText(l.label, 35, 34 + i * 20);
  });
}

function updateChart(index) {
  chart.data.labels = [...Array(index + 1).keys()];
  chart.data.datasets[0].data = seirData.S.slice(0, index + 1);
  chart.data.datasets[1].data = seirData.E.slice(0, index + 1);
  chart.data.datasets[2].data = seirData.I.slice(0, index + 1);
  chart.data.datasets[3].data = seirData.R.slice(0, index + 1);
  chart.update();
}

function downloadCSV() {
  let csv = "Day,Susceptible,Exposed,Infected,Recovered\n";
  for (let i = 0; i < seirData.S.length; i++) {
    csv += `${i + 1},${seirData.S[i]},${seirData.E[i]},${seirData.I[i]},${seirData.R[i]}\n`;
  }

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", "seir_simulation_results.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

window.addEventListener("DOMContentLoaded", () => {
  const ctx = document.getElementById("seirChart").getContext("2d");
  chart = new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [
        { label: "Susceptible", borderColor: "green", data: [], fill: false },
        { label: "Exposed", borderColor: "orange", data: [], fill: false },
        { label: "Infected", borderColor: "red", data: [], fill: false },
        { label: "Recovered", borderColor: "blue", data: [], fill: false }
      ]
    },
    options: {
      responsive: true,
      animation: false,
      scales: {
        x: { title: { display: true, text: "Days" } },
        y: { title: { display: true, text: "Population" } }
      }
    }
  });

  const manualForm = document.getElementById("manualFormInner");
  const csvForm = document.getElementById("csvFormInner");
  const manualBtn = document.getElementById("manualSubmit");
  const csvBtn = document.getElementById("csvSubmit");
  const fileInput = document.getElementById("csvFile");

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
      csvBtn.classList.add("uploaded");
      csvBtn.textContent = "✅ File Ready";
    }
  });

  const handleFormSubmit = async (form, isManual) => {
    const submitBtn = isManual ? manualBtn : csvBtn;
    submitBtn.textContent = "⏳ Simulating...";

    const formData = new FormData(form);
    const res = await fetch("/simulate", { method: "POST", body: formData });
    const json = await res.json();

    if (json.status === "success") {
      seirData = json.history;
      x = json.x;
      y = json.y;
      dailyStatus = json.daily_status;

      updateChart(seirData.S.length - 1);
      document.getElementById("summaryBox").textContent =
        `Peak: ${json.peak}\nDay: ${json.peak_day}\nR₀: ${json.r0.toFixed(2)}`;
      document.getElementById("bulletinBox").textContent = json.bulletin;

      const list = document.getElementById("recommendationList");
      list.innerHTML = "";
      if (json.recommendation?.length) {
        json.recommendation.forEach(rec => {
          const li = document.createElement("li");
          li.textContent = rec;
          list.appendChild(li);
        });
      }

      document.getElementById("bfsBox").textContent = json.bfs_trace?.length
        ? `IDs of traced contacts: ${json.bfs_trace.join(', ')}` : "No infection traced.";

      document.getElementById("priorityBox").textContent = json.priority_vaccinated?.length
        ? `Vaccinated (by priority): ${json.priority_vaccinated.join(', ')}` : "No priority vaccination applied.";

      drawMap(x, y, json.status);
      submitBtn.textContent = "Run Again";
    } else {
      alert("Simulation failed: " + json.message);
      submitBtn.textContent = "Run Simulation";
    }
  };

  manualForm.addEventListener("submit", (e) => {
    e.preventDefault();
    handleFormSubmit(manualForm, true);
  });

  csvForm.addEventListener("submit", (e) => {
    e.preventDefault();
    handleFormSubmit(csvForm, false);
  });
});
